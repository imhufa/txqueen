set-executionpolicy -Scope LocalMachine -ExecutionPolicy Unrestricted
bcdedit /set hypervisorlaunchtype off
Disable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-Hypervisor
Disable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-Services
Disable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-Management-Powershell
bcdedit /enum
Get-ComputerInfo -Property "HyperV*"
pause
Set-ExecutionPolicy -Scope LocalMachine -ExecutionPolicy Bypass
pause
