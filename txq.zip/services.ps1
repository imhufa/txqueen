Get-Service -Name "VBoxSDS" | Set-Service -StartupType "Automatic"
Start-Service -Name "VboxSDS"
Get-Service -Name "hyper*" | Where-Object {$_.Status -eq "Running"} | Stop-Service
Get-Service -Name "hyper*" | Set-Service -StartupType "Disabled"
Clear-Host
Get-Service -Name "hyper*" | Format-Table -Autosize -Wrap
Get-Service -Name "VBoxSDS" | Formate-Table -Autosize -Wrap
pause

